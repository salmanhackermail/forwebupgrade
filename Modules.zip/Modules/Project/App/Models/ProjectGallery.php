<?php

namespace Modules\Project\App\Models;

use Illuminate\Database\Eloquent\Model;

class ProjectGallery extends Model
{

    protected $fillable = [];

}
