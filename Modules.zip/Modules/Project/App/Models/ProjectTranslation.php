<?php

namespace Modules\Project\App\Models;

use Illuminate\Database\Eloquent\Model;

class ProjectTranslation extends Model
{

    protected $fillable = [];

}
