<?php

return [
    'name' => 'Language',
];
