<?php

namespace Modules\FAQ\Database\Seeders;

use Illuminate\Database\Seeder;

class FAQDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

    }
}
