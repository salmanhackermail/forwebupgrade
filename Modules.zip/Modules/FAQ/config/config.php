<?php

return [
    'name' => 'FAQ',
];
