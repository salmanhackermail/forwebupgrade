<?php

namespace Modules\Wishlist\Database\Seeders;

use Illuminate\Database\Seeder;

class WishlistDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

    }
}
