<?php

return [
    'name' => 'Brand'
];
