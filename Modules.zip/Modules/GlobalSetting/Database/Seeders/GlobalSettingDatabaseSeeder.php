<?php

namespace Modules\GlobalSetting\Database\Seeders;

use Illuminate\Database\Seeder;

class GlobalSettingDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

    }
}
