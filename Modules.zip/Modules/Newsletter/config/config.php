<?php

return [
    'name' => 'Newsletter',
];
