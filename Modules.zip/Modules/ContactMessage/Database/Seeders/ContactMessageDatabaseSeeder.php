<?php

namespace Modules\ContactMessage\Database\Seeders;

use Illuminate\Database\Seeder;

class ContactMessageDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

    }
}
