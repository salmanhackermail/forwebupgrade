<?php

namespace Modules\Blog\App\Models;

use Illuminate\Database\Eloquent\Model;

class BlogCategoryTranslation extends Model
{

    protected $fillable = [];
}
