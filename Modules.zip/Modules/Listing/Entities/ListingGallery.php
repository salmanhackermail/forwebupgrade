<?php

namespace Modules\Listing\Entities;

use Illuminate\Database\Eloquent\Model;

class ListingGallery extends Model
{
    protected $fillable = [];
}
