<?php

return [
    'name' => 'Ecommerce',
];
