<?php

namespace Modules\Page\App\Models;

use Illuminate\Database\Eloquent\Model;

class SliderTranslation extends Model
{
    protected $guarded = [];
}
